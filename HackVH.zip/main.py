x = select.value(bthour)
y = select.value(wthour)



from datetime import datetime

val1=datetime(2021, 1, 18, y)
val2=datetime(2021, 1, 17, x)

difference = val1 - val2
# print(type(difference))

print(difference.total_seconds() /60**2) # time difference in total hours
print(difference.total_seconds() /60**2*10)

time = (difference.total_seconds() /60**2)
points = (difference.total_seconds() /60**2*10)

time = form.getvalue('time').capitalize()

#!/usr/bin/python
# Import modules for CGI handling
import cgi, cgitb
# Create instance of FieldStorage
form = cgi.FieldStorage()
# Get data from fields
first_name = form.getvalue('first_name')
last_name = form.getvalue('last_name')
print "Content-type:text/html\r\n\r\n"
print "<html>"
print "<head>"
print "<title>SleepWell</title>"
print "</head>"
print "<body>"
print("<p>You slept {} hours!You earned {}points.</p>".format (time, points))
print "</body>"
print "</html>"